package com.Project.JobConnectPortal.DAO;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.Project.JobConnectPortal.Model.Interview;
import com.Project.JobConnectPortal.Model.JobApplications;
import com.Project.JobConnectPortal.Model.JobPostings;
import com.Project.JobConnectPortal.Repository.InterviewRepo;
import com.Project.JobConnectPortal.Repository.JobApplicationsRepo;
import com.Project.JobConnectPortal.Repository.JobPostingsRepo;

@Repository
public class EmployerDAO {

    @Autowired
    private InterviewRepo interviewRepo;

    @Autowired
    private JobPostingsRepo jobRepo;

    @Autowired
    private JobApplicationsRepo applicationRepo;

    // Job Operations
    public List<JobPostings> getAllJobs() {
        return jobRepo.findAll();
    }

    public String addJob(JobPostings job) {
        if (job.getPostDate() == null || job.getPostDate().isEmpty()) {
            job.setPostDate(java.time.LocalDateTime.now().toString());
        }
        if (job.getStatus() == null || job.getStatus().isEmpty()) {
            job.setStatus("pending");
        }
        jobRepo.save(job);
        return "Job added successfully!";
    }

    public String updateJob(int jobId, JobPostings job) {
        JobPostings existingJob = jobRepo.findById(jobId);
        if (existingJob != null) {
            existingJob.setJobName(job.getJobName());
            existingJob.setDepartment(job.getDepartment());
            existingJob.setSkills(job.getSkills());
            existingJob.setExperience(job.getExperience());
            existingJob.setJobDescription(job.getJobDescription());
            existingJob.setSalary(job.getSalary());
            existingJob.setEmployerId(job.getEmployerId());
            existingJob.setCompanyName(job.getCompanyName());
            existingJob.setStatus(job.getStatus());
            jobRepo.save(existingJob);
            return "Job updated successfully!";
        }
        return "Job not found!";
    }

    public String deleteJob(int jobId) {
        jobRepo.deleteById(jobId);
        return "Job deleted successfully!";
    }

    // Application Operations
    public List<JobApplications> getAllApplications() {
        return applicationRepo.findAll();
    }

    public String insertApplication(JobApplications application) {
        applicationRepo.save(application);
        return "Application added successfully!";
    }

    public String updateApplication(int applicationId, String status) {
        Optional<JobApplications> app = applicationRepo.findById(applicationId);
        if (app.isPresent()) {
            app.get().setStatus(status);
            applicationRepo.save(app.get());
            return "Application updated successfully!";
        }
        return "Application not found";
    }

    public String deleteApplication(int applicationId) {
        applicationRepo.deleteById(applicationId);
        return "Application deleted successfully!";
    }

    // Interview Operations
    public List<Interview> getAllInterviews() {
        return interviewRepo.findAll();
    }

    public ResponseEntity<Interview> addInterview(Interview interview) {
        return new ResponseEntity<>(interviewRepo.save(interview), HttpStatus.CREATED);
    }

    public ResponseEntity<Interview> getInterviewById(int interviewId) {
        Optional<Interview> interview = interviewRepo.findById(interviewId);
        return interview.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                        .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Old method
    /*
    public ResponseEntity<String> updateInterview(int interviewId, Interview interview) {
        Optional<Interview> existingInterview = interviewRepo.findById(interviewId);
        if (existingInterview.isPresent()) {
            existingInterview.get().setFeedback(interview.getFeedback());
            existingInterview.get().setInterview_status(interview.getInterview_status());
            interviewRepo.save(existingInterview.get());
            return new ResponseEntity<>( HttpStatus.OK);
        }
        return new ResponseEntity<>( HttpStatus.NOT_FOUND);
    }
    */

    // New method for partial update
    public ResponseEntity<String> updateInterview(int interviewId, String status, String feedback) {
        Optional<Interview> existingInterview = interviewRepo.findById(interviewId);
        if (existingInterview.isPresent()) {
            existingInterview.get().setInterview_status(status);
            existingInterview.get().setFeedback(feedback);
            interviewRepo.save(existingInterview.get());
            return new ResponseEntity<>(HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    public ResponseEntity<Void> deleteInterview(int interviewId) {
        Optional<Interview> interview = interviewRepo.findById(interviewId);
        if (interview.isPresent()) {
            interviewRepo.deleteById(interviewId);
            return new ResponseEntity<>(HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Add or update this method to schedule an interview when an application is approved
    public void scheduleInterviewForApplication(int applicationId) {
        Optional<JobApplications> appOpt = applicationRepo.findById(applicationId);
        if (appOpt.isPresent()) {
            JobApplications app = appOpt.get();
            Interview interview = new Interview();
            // Generate a new interview_Id (if not auto-increment)
            interview.setInterview_Id(generateNewInterviewId());
            interview.setApplication_id(app.getApplicationId());
            interview.setUserId(app.getUserId());
            interview.setName(app.getName());
            interview.setInterview_status("Scheduled");
            interview.setFeedback("");
            // Use java.sql.Date for DATE columns, or java.sql.Timestamp for DATETIME/TIMESTAMP columns
            interview.setInterview_date(new java.sql.Date(System.currentTimeMillis()));
            interviewRepo.save(interview);
        }
    }

    // Helper method to generate a new interview ID (if not auto-increment)
    private int generateNewInterviewId() {
        List<Interview> all = interviewRepo.findAll();
        return all.stream().mapToInt(Interview::getInterview_Id).max().orElse(0) + 1;
    }
}
