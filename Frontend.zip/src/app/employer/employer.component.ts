import { Component } from '@angular/core';
import { Interview } from '../interview';
import { Application } from '../application';
import { Job } from '../job';
import { FormBuilder, FormGroup } from '@angular/forms';
import { JobsService } from '../jobs.service';
import { InterviewServiceService } from '../interview-service.service';
import { ApplicationService } from '../application.service';
 
@Component({
  selector: 'app-employer',
  standalone: false,
  templateUrl: './employer.component.html',
  styleUrl: './employer.component.css'
})
export class EmployerComponent {
  title = 'myapp';
 
 
  
 
 visibleSections = {
  jobs: true,
  interviews: true,
  applications: true
};
 
toggleSection(section: 'jobs' | 'interviews' | 'applications') {
  this.visibleSections[section] = !this.visibleSections[section];
}
 
  JobForm!:FormGroup;
    constructor(private jobService : JobsService,private fb:FormBuilder, private interviewService: InterviewServiceService, private applicationService: ApplicationService){
      
      this.JobForm=this.fb.group({
        job_name:[''],
        company_name:[''], // Added company_name
        department:[''],
        skills:[''],
        experience:[''],
        job_description:[''],
        salary:[''],
        emp_id:[''],
      })
    }
    bAdd=false;
    strAddNames='';
    addJobList(){
      this.bAdd=true;
     
      this.strAddNames="Add Record"
    }
    t=false
    t1=false
    t3=false
    editingJobId: number | null = null; // Track which job is being edited
    
    AddJobRecord() {
  if (this.JobForm.invalid) {
    // Mark all fields as touched to trigger validation messages
    this.JobForm.markAllAsTouched();
    alert('Please fill in all required fields.');
    return;
  }

  const jobObj = new Job(
    this.JobForm.get('job_name')?.value,
    this.JobForm.get('company_name')?.value,
    this.JobForm.get('department')?.value,
    this.JobForm.get('skills')?.value,
    this.JobForm.get('experience')?.value,
    this.JobForm.get('job_description')?.value,
    this.JobForm.get('salary')?.value,
    this.JobForm.get('emp_id')?.value
  );

  if (this.editingJobId) {
    // Edit mode
    this.jobService.updateJob(this.editingJobId, jobObj).subscribe({
      next: (data) => {
        alert('Record updated successfully');
        this.getAllJobsList();
        this.resetForm();
        console.log('Update:', JSON.stringify(data));
      },
      error: (err) => console.error('Error updating record:', err),
      complete: () => console.log('Update operation completed')
    });
  } else {
    // Add mode
    this.jobService.insertJob(jobObj).subscribe({
      next: (data) => {
        alert('Record inserted successfully');
        this.getAllJobsList();
        this.resetForm();
        console.log('Insert:', JSON.stringify(data));
      },
      error: (err) => console.error('Error inserting record:', err),
      complete: () => console.log('Insert operation completed')
    });
  }
}

private resetForm() {
  this.JobForm.reset();
  this.editingJobId = null;
  this.strAddNames = 'Add Record';
}

 
    bSearch=true;
    searchForm(){
      if(this.bSearch==true){
        this.bSearch=false;
      }
    }
 
    jobLst : any;
    showTable: boolean = false;
    getAllJobsList(){
      this.t=true
      this.t1=false
      this.t3=false
      this.jobService.getAllJobs().subscribe({
        next :(data) =>{this.jobLst= data;
          this.showTable = true;},
        error :(err) => console.log ("unable to fetch from server"+err),
        complete : () => console.log ("fetching data from server is complete")
      })
    }
 
    EditJobRecord(jobRecord: any) {
      this.bAdd = true;
      this.strAddNames = "Edit Record";
      this.editingJobId = jobRecord.jobId;
      this.JobForm.patchValue({
        job_name: jobRecord.job_name || jobRecord.jobName,
        company_name: jobRecord.company_name || jobRecord.companyName,
        department: jobRecord.department,
        skills: jobRecord.skills,
        experience: jobRecord.experience,
        job_description: jobRecord.job_description || jobRecord.jobDescription,
        salary: jobRecord.salary,
        emp_id: jobRecord.emp_id || jobRecord.employerId,
      });
    }
 
    DeleteJobRecord(job_id:number){
 
      this.jobService.deleteJobRecord(job_id).subscribe({
        next : (data) => {alert ("record deleted successfully");
          this.getAllJobsList();
          console.log (JSON.stringify(data));
        },
        error : (err) => {alert (JSON.stringify(err))},
        complete : () => console.log ('delete operation is complete')
      });
    }
  interviews: Interview[] = [];  
    ngOnInit(): void {
      this.getAllJobsList();
      this.interviews = this.interviewService.getInterviews();
      this.applicationService.getAllApplications().subscribe(applications => {
        console.log(applications); // Check the data structure
        this.applications = applications;
        this.filteredApplications = applications; // Initialize with all applications
      });
    }
 
    // Mark interview as completed
    completeInterview(id: number): void {
      this.interviewService.updateInterviewStatus(id, 'Completed');
    }
 
    // Mark interview as cancelled
    cancelInterview(id: number): void {
      this.interviewService.updateInterviewStatus(id, 'Cancelled');
    }
 
    
   
     
    submitFeedback(interview_Id: number, interview_status: string, feedback: string): void {
      console.log('submitFeedback called with interview_Id:', interview_Id, 'status:', interview_status, 'feedback:', feedback);
  if (!feedback || feedback.trim() === '') {
    alert('Feedback cannot be empty.');
    return;
  }
 
  this.interviewService.updateInterviewStatusAndFeedback(interview_Id, interview_status, feedback)
    .subscribe({
      next: (response) => {
        alert('Feedback submitted successfully.');
        console.log('Feedback submitted:', response);
      },
      error: (error) => {
        console.error('Error submitting feedback:', error,' ..',feedback);
        alert('Failed to submit feedback. Please try again.');
      }
    });
}
 
 
     
 
     
    interviewList :any;
    getInterviewList(){
      this.t=false
      this.t1=true
      this.t3=false
      this.interviewService.getAllInterviews().subscribe({
        next :(data) =>{this.interviewList=data;},
        error:(err) =>alert(err),
        complete:()=> console.log("fetching done")
 
        })
    }
 
    applications: Application[] = [];
      filteredApplications: Application[] = [];
      filterQualifications: string = ''; // Filter for qualifications
      filterExperience: string = '';
   
 
      applyFilter(): void {
        // Call the service's filteredApplications method to get the filtered results
        this.filteredApplications = this.applicationService.filteredApplications(this.filterQualifications, this.filterExperience);
      }
     
     
      private interview:Interview[]=[];
      private scheduleInterview(application_id: number): void {
  const application = this.applications.find(app => app.applicationId === application_id);
 
  if (application) {
    const interview: Interview = {
      interview_Id: this.interview.length + 1, // probably +1 not length for unique ID
      interview_date: new Date(),
      application_id: application.applicationId,
      userId: application.userId,
      name: application.name,
      interview_status: 'Scheduled',
      feedback: ''
    };
   
    this.interviewService.saveInterview(interview).subscribe({
      next: (response: Interview) => {
        console.log('Interview successfully scheduled:', response);
        // Optionally update local state or UI here
      },
      error: (error) => {
        console.error('Error scheduling interview:', error);
      }
    });
  }
}
 
     
      // Approve the application and schedule an interview
      approve(application_id: number): void {
        this.applicationService.updateApplicationStatus(application_id, 'Approved');
        // After approval, automatically schedule an interview
        const application = this.applications.find(app => app.applicationId === application_id);
       
        if (application) {
          const interview: Interview = {
            interview_Id:this.interview.length,
            interview_date: new Date(),
            application_id: application.applicationId,
            userId: application.userId,
            name: application.name,
            interview_status: 'Scheduled',
            feedback: '' // No feedback yet
          };
        //  this.interviewService.scheduleInterview(interview);
          this.interviewService.saveInterview(interview).subscribe((response: Interview) => {
            // Optionally, you can handle the response here if you need to update the UI with the newly added interview
            console.log('Interview successfully scheduled:', response);
          }, error => {
            console.error('Error scheduling interview:', error);
          });
        }
      }
     
      // Reject the application
      reject(application_id: number): void {
        this.applicationService.updateApplicationStatus(application_id, 'Rejected');
      }
}