import { Injectable } from '@angular/core';
import { Interview } from './interview';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
 
@Injectable({
  providedIn: 'root'
})
export class InterviewServiceService {
 
  private interviews: Interview[] = [];
 
  constructor(private http:HttpClient) {}
 
  getInterviews(): Interview[] {
    return this.interviews;
  }
 
  scheduleInterview(interview: Interview): void {
    this.interviews.push(interview);
  }
 
  updateInterviewStatus(id: number, status: string): void {
    const interview = this.interviews.find((int) => int.interview_Id === id);
    if (interview) {
      interview.interview_status = status;
    }
  }
 
  // Update feedback for the interview
  updateFeedback(id: number, feedback: string): void {
    const interview = this.interviews.find((int) => int.interview_Id === id);
    if (interview) {
      interview.feedback = feedback;
    }
  }
  apiUrl='http://localhost:8091/api/employer/addInterview'
  saveInterview(interview: Interview): Observable<Interview> {
    return this.http.post<Interview>(this.apiUrl, interview);
  }
 
  updateInterviewStatusAndFeedback(interview_Id: number, interview_status: string, feedback: string): Observable<any> {
    const updateUrl = `http://localhost:8091/api/employer/updateInterview/${interview_Id}`;
    return this.http.put<any>(updateUrl, {
      interview_status: interview_status,
      feedback: feedback
    }, { responseType: 'text' as 'json' });
  }
   
  getAllInterviews():Observable<any>{
    let strUrlg='http://localhost:8091/api/employer/interviews';
    alert("Url"+strUrlg);
    return this.http.get<string>(strUrlg);
  }
}
 