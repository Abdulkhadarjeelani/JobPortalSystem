import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-insights',
  standalone: false,
  templateUrl: './insights.component.html',
  styleUrl: './insights.component.css'
})
export class InsightsComponent {

  @Input() jobInsights: any[] = [];  // Input for jobInsights array
  @Output() fetchInsights = new EventEmitter<void>();  // Output for triggering data fetch

  // Triggering the fetch when the button is pressed
  onFetchInsights(): void {
    this.fetchInsights.emit();  // Emit event to parent component
  }
}
