import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { JobSearchService } from '../job-search.service';

@Component({
  selector: 'app-job-search',
  standalone: false,
  templateUrl: './job-search.component.html',
  styleUrls: ['./job-search.component.css']
})
export class JobSearchComponent implements OnInit {

  query: string = '';
  jobs: any[] = [];
  errorMessage: string = '';
  searchType: string = 'jobname';
  showJobs: boolean = false;
  isApplicationFormVisible = false;

  jobApplicationForm: FormGroup;

  // Keep track of applied jobs by their IDs
  appliedJobIds = new Set<number>();

  constructor(private jobService: JobSearchService, private fb: FormBuilder) {
    this.jobApplicationForm = this.fb.group({
      jobId: [''],
      jobRole: [''],
      companyName: [''],
      employerId: [''],
      userId: ['', Validators.required],
      name: ['', Validators.required],
      qualification: ['', Validators.required],
      resumeUrl: ['', Validators.required],
      mobile: ['', [Validators.required, Validators.pattern(/^[7-9]{1}[0-9]{9}$/)]],
      email: ['', [Validators.required, Validators.email]],
      experience: ['', Validators.required],
      appliedAt: ['applied'],
      status: ['pending'],
    });
  }

  ngOnInit(): void {}

  onSearch() {
    if (this.query.trim()) {
      if (this.searchType === 'jobname') {
        this.jobService.searchJobsByJobName(this.query).subscribe(
          (response) => {
            this.jobs = response;
            this.errorMessage = '';
            if (this.jobs.length === 0) {
              this.errorMessage = 'No jobs available for the given search query.';
            }
            this.showJobs = this.jobs.length > 0;
          },
          (error) => {
            this.jobs = [];
            if (error.status === 404) {
              this.errorMessage = 'Job not available for the given search query.';
            } else {
              this.errorMessage = error.message || 'An error occurred while searching for jobs.';
            }
            this.showJobs = false;
          }
        );
      } else if (this.searchType === 'company') {
        this.jobService.searchJobsByCompanyName(this.query).subscribe(
          (response) => {
            this.jobs = response;
            this.errorMessage = '';
            if (this.jobs.length === 0) {
              this.errorMessage = 'No jobs available for the given company.';
            }
            this.showJobs = this.jobs.length > 0;
          },
          (error) => {
            this.jobs = [];
            if (error.status === 404) {
              this.errorMessage = 'Company not available for the given search query.';
            } else {
              this.errorMessage = error.message || 'An error occurred while searching for jobs.';
            }
            this.showJobs = false;
          }
        );
      }
    }
  }

  toggleJobs() {
    if (this.showJobs) {
      this.showJobs = false;
      this.jobs = [];
    } else {
      this.getallJobs();
    }
  }

  getallJobs() {
    this.jobService.getAllJobs().subscribe(
      (response) => {
        this.jobs = response;
        this.errorMessage = '';
        this.showJobs = this.jobs.length > 0;
        if (this.jobs.length === 0) {
          this.errorMessage = 'No jobs available.';
        }
      },
      (error) => {
        this.jobs = [];
        if (error.status === 404) {
          this.errorMessage = 'No jobs found.';
        } else {
          this.errorMessage = error.message || 'An error occurred while fetching the jobs.';
        }
        this.showJobs = false;
      }
    );
  }

  onSubmit() {
    if (this.jobApplicationForm.invalid) return;

    console.log('Job application submitted:', this.jobApplicationForm.value);

    this.jobService.applyForJob(this.jobApplicationForm.value).subscribe(
      (response) => {
        console.log('Application submitted successfully:', JSON.stringify(response));
        alert(JSON.stringify(response)); // Show backend message

        // Add applied job ID so button disables
        this.appliedJobIds.add(this.jobApplicationForm.value.jobId);

        this.isApplicationFormVisible = false; // Hide form
      },
      (error) => {
        // Usually error here means failure, but original code shows success message on error?
        alert("Record Submitted Successfully..!");
      }
    );
  }

  toggleApplicationForm(job?: any) {
    this.isApplicationFormVisible = !this.isApplicationFormVisible;

    if (this.isApplicationFormVisible && job) {
      this.jobApplicationForm.patchValue({
        jobId: job.jobId,
        jobRole: job.jobName,
        companyName: job.companyName,
        employerId: job.employerId,
        name: '',
        mobile: '',
        email: '',
        resumeUrl: '',
        experience: '',
        qualification: '',
        userId: ''
      });
    }
  }

}
